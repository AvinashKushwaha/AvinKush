import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SeatLayoutComponent } from './seat-layout/seat-layout.component';
import { MaterialModule } from '../material/material.module';
import { MatGridListModule } from '@angular/material/grid-list';
import { SharedRoutingModule } from './shared-routing.module';




@NgModule({
  declarations: [SeatLayoutComponent],
  imports: [
    CommonModule,
    MaterialModule,
    MatGridListModule,
    SharedRoutingModule
  ], exports: [SeatLayoutComponent]
})
export class SharedModule { }
