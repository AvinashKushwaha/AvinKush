export class Passenger {
    "customerName": string;
    "seatNumber": string;
    "checkIn": boolean;
    "category": string;
    "ancillaryService": string[];
    "specialMeal": string;
    "shoppingItem": string[];
    "flightId": string;
    "passport": string;
    "address": string;
    "DOB": string;
}