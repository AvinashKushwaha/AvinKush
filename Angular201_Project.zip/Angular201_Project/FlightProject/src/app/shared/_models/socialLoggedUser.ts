export class SocialLoggedUser {
    firstName: string;
    lastName: string;
    image: string;
    gmail: string;
    token: string;
}