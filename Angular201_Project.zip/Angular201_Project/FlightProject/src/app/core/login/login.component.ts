import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { first } from 'rxjs/operators';
//import { SocialAuthService, GoogleLoginProvider, SocialUser  } from 'angularx-social-login';
import { AuthenticationService, UserService } from '../../shared/_services';

import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material/icon';
import { User } from '../../shared/_models/user';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

const googlelogoURL = "https://blog.hubspot.com/hubfs/image8-2.jpg";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  //social: SocialUser;
  loading = false;
  submitted = false;
  returnUrl: string;
  error= '';
  suser: any;
  myStyle: object = {};
  myParams: object = {};
  width: number = 100;
  height: number = 100;
  hide = true;
  //socialUser = SocialUser;
  

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    //public authService: SocialAuthService,
    private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer,
    private toastrService: ToastrService
  ) {
    this.matIconRegistry.addSvgIcon(
      "logo",
      this.domSanitizer.bypassSecurityTrustResourceUrl(googlelogoURL));
    

      //Redirect to home page if already logged in

      if(this.authenticationService.currentUserValue) {
        this.router.navigate(['/']);
      }
   }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });

    /*this.authService.authState.subscribe((user) => {
      this.suser = user;
      this.submitted = (user != null);
    });*/

    //To return url from route parameters or return default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

  }

  // For easy accessing the form field
  get f() {
    return this.loginForm.controls;
  }

  onSubmit() {
    this.submitted = true;

    // Dont submit if form is invalid
    if(this.loginForm.invalid){
      return;
    }

    this.loading = true;
    console.log(this.loading)
    //this.authenticationService.login(this.loginForm.get('userId').value, this.loginForm.get('password').value)
    console.log(this.f.username.value, this.f.password.value)
    console.log(this.returnUrl)
    this.authenticationService.login(this.f.username.value, this.f.password.value)
        .pipe(first())
        .subscribe(
          data => {
           // this.router.navigate(['admin']);
            this.router.navigate([this.returnUrl]);
            this.toastrService.success('Welcome to Flight Service');
            
          },

          error => {
            this.error = error;
            this.loading = false;
            this.toastrService.error('You have entered the wrong credentials');
          }
        );

  }

  /*socialSignIn(socialProvider: string) {

    if(socialProvider == "google") {
      this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).then(x => {
        this.social = x;
        console.log(this.social);
        this.authenticationService.socialLogin(this.social);
        this.toastrService.success('Welcome Staff to flight Service');
        this.router.navigate([this.returnUrl]);
      });
    }
  }*/

}
