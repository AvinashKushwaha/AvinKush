import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AdminComponentComponent } from '../admin/admin-component/admin-component.component';
import { CheckinComponentComponent} from '../checkin/checkin-component/checkin-component.component';
import { AuthGuard } from '../shared/_helpers/auth.guard';
import { Role } from '../shared/_models/role';


const routes: Routes = [
    {
        path: '' ,
        component: HomeComponent , 
        canActivate: [AuthGuard]
    },

    {
        path: 'login',
        component: LoginComponent

    },

    {
        path: 'checkin',
        loadChildren: () => import('../checkin/checkin.module').then(m => m.CheckinModule),
        canActivate: [AuthGuard]
    },

    {
        path: 'admin',
        loadChildren: () => import('../admin/admin.module').then(m => m.AdminModule),
        canActivate: [AuthGuard],
        data: {roles: [Role.Admin]}
    },

    {
        path: 'inflight',
        loadChildren: () => import('../inflight/inflight.module').then(m => m.InflightModule),
        canActivate: [AuthGuard]
    },

    //It will redirect to home
    {
        path: '**',
        redirectTo: ''
    }
];

@NgModule({
    imports : [RouterModule.forChild(routes)],
    exports : [RouterModule]
})

export class CoreRoutingModule {}