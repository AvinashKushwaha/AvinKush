import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreRoutingModule } from './core-routing.module';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';

import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { ToastrModule} from 'ngx-toastr';

import { fakeBackendProvider, JwtInterceptor, ErrorInterceptor } from '../shared/_helpers';

//import {SocialLoginModule } from 'angularx-social-login';
//import { AuthServiceConfig } from 'angularx-social-login';
import { SocialLoginModule, SocialAuthServiceConfig } from 'angularx-social-login';
import { GoogleLoginProvider } from 'angularx-social-login';
import { HeaderComponent } from '../header/header.component';

/*const config = new AuthServiceConfig([
  {
    id: GoogleLoginProvider.PROVIDER_ID,
    provider: new GoogleLoginProvider('3159933440-mg04p2h0e2a8vksifq4va13h6nvodu5a.apps.googleusercontent.com')
  }
]);

export function provideConfig() {
  return config;
}*/

@NgModule({
  declarations: [HomeComponent, LoginComponent],
  imports: [
    CommonModule,
    CoreRoutingModule,
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatFormFieldModule,
    MatIconModule,
    //SocialLoginModule,
    MatInputModule,
    MatButtonModule,
    ToastrModule.forRoot(),
    FormsModule
  ],
  //exports: [HeaderComponent],
  providers: []
  /*providers: [
    {
      provide: 'SocialAuthServiceConfig',
      useValue: {
        autoLogin: true,
        providers: [
          {
            id: GoogleLoginProvider.PROVIDER_ID,
            provider: new GoogleLoginProvider('3159933440-mg04p2h0e2a8vksifq4va13h6nvodu5a.apps.googleusercontent.com')
          },
          { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
          { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
          fakeBackendProvider
        ],
      } as SocialAuthServiceConfig
    } 
  ]*///, exports: [HeaderComponent]
 /* providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    {
      provide: AuthServiceConfig,
      useFactory: provideConfig
    },

    fakeBackendProvider

  ] */
  //bootstrap: []
})
export class CoreModule { }
