import { Component, OnInit } from '@angular/core';
import { SidenavService } from '../../shared/services/sidenav.service';
import { animateText, onMainContentChange } from '../../shared/animation/animation';

@Component({
  selector: 'app-checkin-component',
  templateUrl: './checkin-component.component.html',
  styleUrls: ['./checkin-component.component.css'],
  animations: [onMainContentChange, animateText]
})
export class CheckinComponentComponent implements OnInit {

  public onSideNavChange: boolean;

  constructor(private _sidenavService: SidenavService) {
    this._sidenavService.sideNavState$.subscribe(res => {
      console.log(res)
      this.onSideNavChange = res;
    })
  }

  ngOnInit(): void {
  }

}
