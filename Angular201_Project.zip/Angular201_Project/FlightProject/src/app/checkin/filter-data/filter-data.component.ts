import { Component, OnInit, ViewChild, OnChanges } from '@angular/core';
import { MatOptionSelectionChange } from '@angular/material/core';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { ToastrService } from 'ngx-toastr';
import { MatSort } from '@angular/material/sort';
import { MatDialog } from '@angular/material/dialog';
import { Action } from 'rxjs/internal/scheduler/Action';
import { SeatChangeComponent } from '../seat-change/seat-change.component';
import { MatPaginator } from '../../../../node_modules/@angular/material/paginator';
import { FlightDataService } from '../../shared/flightData.service';
import { MatTableDataSource } from '../../../../node_modules/@angular/material/table';

@Component({
  selector: 'app-filter-data',
  templateUrl: './filter-data.component.html',
  styleUrls: ['./filter-data.component.css']
})
export class FilterDataComponent implements OnInit {

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  flights: any = [];
  flightNameList: any = [];
  distinctFlights: any = [];
  flightIdpipe: any;
  passengers: any;
  flightName: any;
  flightId: any;
  singleflight: any = [];
  resultedPassenger: any;
  someValue: any;
  resultsLength = 0;
  pagesize = 10;
  dialogData: any;
  result: any;
  selectedSeatChange: any;
  displayedColumns = ['customerName', 'AncillaryServices', 'seatNumber', 'changeSeat'];
  ELEMENT_DATA: Element[] = [];
  dataSource: any;

  constructor(private checkInService: FlightDataService,
              private toastrService: ToastrService,
              private dialog: MatDialog) { }

  ngOnInit(): void {
    this.checkInService.getflights().subscribe(data => {
      this.flights = data;
      this.getUniqueFlight();
    })
  }

  getUniqueFlight() {
    for(let i=0; i<this.flights.length; i++){
      this.flightNameList.push(this.flights[i].flightName);
    }

    const distinct = (value, index, self) => {
      return self.indexOf(value) === index;
    }
    this.distinctFlights = this.flightNameList.filter(distinct);
  }


  onChange(event: MatOptionSelectionChange) {
    this.flightName = this.distinctFlights[event.source.value];
    this.checkInService.getFlightByName(this.flightName).subscribe(data => {
      this.flightId = data;
    });
  }

  onClickWheelChair($event: MatCheckboxChange){
    let res = $event.checked;
    if(res) {
      this.someValue = "wheelchair";
    }
    else if (!res) {
      this.someValue = "";
    }
    return res;
  }

  onClickInfant($event: MatCheckboxChange){
    let res = $event.checked;
    if(res) {
      this.someValue = "infant";
    }
    else if (!res) {
      this.someValue = "";
    }
    return res;
  }

  onClickCheckIn($event: MatCheckboxChange){
    let res = $event.checked;
    if(res) {
      this.someValue = "checkIn";
    }
    else if (!res) {
      this.someValue = "";
    }
    return res;
  }

  onCheck($event: MatCheckboxChange){
    let res = $event.checked;
    if(res) {
      this.flightIdpipe = $event.source.value;
      this.checkInService.getFlightById(this.flightIdpipe).subscribe(data => {
        this.singleflight = data;
        this.resultedPassenger = this.singleflight[0].passengers;
        this.checkInService.saveFlight(this.singleflight[0]);
        this.ELEMENT_DATA = this.resultedPassenger;
        this.dataSource = new MatTableDataSource<Element>(this.ELEMENT_DATA);
      });
    }
    else {
      this.resultedPassenger = null;
    }
    return this.singleflight;
  }

  openDialog(action: string, obj: any){
    this.dialogData=obj;
    this.selectedSeatChange = this.dialogData.seatNumber;
    const dialogRef = this.dialog.open(SeatChangeComponent, {
      maxWidth: "50%",
      data: this.dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      this.result = dialogResult;
      this.singleflight.passengers = this.resultedPassenger;
      this.checkInService.updatePassengerSeat(this.singleflight[0].id, this.singleflight[0]).subscribe(data => {
        this.toastrService.info('Seat updated successfully');
      },
      
      error => {
        this.toastrService.warning("Error occured while updating...")
      }
      )
    });
  }

}

export interface Element {
  passengerName: string;
  ancillaryService: string;
  seatNumber: string;
}
