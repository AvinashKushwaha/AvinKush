import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CheckinRoutingModule } from './checkin-routing.module';
import { MaterialModule } from '../material/material.module';
import { SidenavService } from '../shared/services/sidenav.service';
import { FilterflightsPipe } from './filterflights.pipe';
import { SharedModule } from '../shared/shared.module';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatPaginator } from '../../../node_modules/@angular/material/paginator';
import { SeatLayoutComponent } from '../shared/seat-layout/seat-layout.component';

import { CheckinComponentComponent } from './checkin-component/checkin-component.component';
import { CheckinSeatComponent } from './checkin-seat/checkin-seat.component';
import { DisplayFlightComponent } from './display-flight/display-flight.component';
import { FilterDataComponent } from './filter-data/filter-data.component';
import { SeatChangeComponent } from './seat-change/seat-change.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { CoreModule } from '../core/core.module';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';



@NgModule({
  declarations: [
    CheckinComponentComponent, 
    CheckinSeatComponent, 
    DisplayFlightComponent, 
    FilterDataComponent, 
    SeatChangeComponent, 
    SidebarComponent,
    FilterflightsPipe
  ],
  imports: [
    CommonModule,
    CheckinRoutingModule,
    MaterialModule,
    SharedModule,
    FormsModule,
    MatDialogModule,
    CoreModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule
  ],
  exports: [SeatLayoutComponent,FilterflightsPipe]
})
export class CheckinModule { }
