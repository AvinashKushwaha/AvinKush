import { Component, OnInit, IterableDiffers, Output, EventEmitter, ViewChild, Input } from '@angular/core';
import { FlightDataService } from '../../shared/flightData.service';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-checkin-seat',
  templateUrl: './checkin-seat.component.html',
  styleUrls: ['./checkin-seat.component.css']
})
export class CheckinSeatComponent implements OnInit {

  rowPassenger: any;
  checkFlight: any;

  constructor(private checkInService: FlightDataService, private router:Router) { }

  @Output() seats = new EventEmitter();

  ngOnInit(): void {

    this.rowPassenger = this.checkInService.getRowPassenger();
    this.checkFlight = this.checkInService.getFlightForCheckIn();
    this.loadSeat();
  }

  seatsLayout: any = {
    totalRows: 9,
    seatsPerRow: 6,
    seatNaming: 'rowType',
    booked: [],
    checked: ['1A']
  }

  loadSeat() {
    let z = 0;
    for (let i=0; i<this.checkFlight[z].passengers.length; i++){
      if(this.checkFlight[z].passengers[i].checkIn === true) {
        this.seatsLayout.checked.push(this.checkFlight[z].passengers[i].seatNumber);
      }
    }
  }

  checkInSeat = "checkInSeat";
  getTrial(event) {
    if(event[0] === this.rowPassenger.seatNumber) {
      this.rowPassenger.checkIn = true;

      for (let i=0; i<this.checkFlight[0].passengers.length; i++) {
        if (this.checkFlight[0].passengers[i].seatNumber === this.rowPassenger.seatNumber) {
          this.checkFlight[0].passengers[i] = this.rowPassenger;
        }
      }

      this.checkInService.updateCheckinStatus(this.checkFlight[0].id, this.checkFlight[0]).subscribe(data => {

      })
    }
  }

  getSelected(event) {
    if(event[0] === this.rowPassenger.seatNumber) {
      this.rowPassenger.checkIn = false;

      for(let i=0; i<this.checkFlight[0].passengers.length; i++) {
        if(this.checkFlight[0].passengers[i].seatNumber = this.rowPassenger.seatNumber) {
          this.checkFlight[0].passengers[i] = this.rowPassenger;
        }
      }

      this.checkInService.updateCheckinStatus(this.checkFlight[0].id, this.checkFlight[0]).subscribe(data => {

      })
    }
  }

  backToCheckIn() {
    this.router.navigate(['checkin/displayflight']);
  }

}
