import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckinSeatComponent } from './checkin-seat.component';

describe('CheckinSeatComponent', () => {
  let component: CheckinSeatComponent;
  let fixture: ComponentFixture<CheckinSeatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckinSeatComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckinSeatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
