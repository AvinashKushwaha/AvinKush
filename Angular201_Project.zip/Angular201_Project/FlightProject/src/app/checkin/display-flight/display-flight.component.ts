import { Component, OnInit, IterableDiffers, Output, EventEmitter, ViewChild } from '@angular/core';
import { MatOptionSelectionChange } from '@angular/material/core';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatPaginator } from '../../../../node_modules/@angular/material/paginator';
import { FlightDataService } from '../../shared/flightData.service';
import { Router, ActivatedRoute } from '../../../../node_modules/@angular/router';
import { MatTableDataSource } from '../../../../node_modules/@angular/material/table';

@Component({
  selector: 'app-display-flight',
  templateUrl: './display-flight.component.html',
  styleUrls: ['./display-flight.component.css']
})
export class DisplayFlightComponent implements OnInit {

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  
  constructor(private checkInService: FlightDataService, private router: Router, private activatedRoute: ActivatedRoute) { }

  @Output() seats = new EventEmitter();

  flights: any = [];
  resultedPassenger: any;
  aeroplane: any = [];
  passengerDetails: any;
  flightDetail: any = [];
  displayColoredSeat = "displayColoredSeat";
  flightName: any;
  flightId: any;
  flightIdpipe: any;
  passengers: any;
  flightNameList: any = [];
  distinctFlights: any = [];
  flightIdCheck: any =[];
  singleflight: any = [];
  displayedColumns = ['customerName', 'AncillaryServices', 'seatNumber', 'checkIN'];
  ELEMENT_DATA: Element[] = [];
  dataSource: any;

  ngOnInit() {

    this.checkInService.getflights().subscribe(data => {
      this.flights = data;
      this.getUniqueFlight();
    })
  }

  getTrial(event) {
    console.log(event);
  }

  getPassenger(value) {
    this.checkInService.getSelectedPassenger(value);
    this.checkInService.getFlightCheckIn(this.singleflight);
    this.router.navigate(['getpassenger'], { relativeTo: this.activatedRoute });
  }

  getUniqueFlight() {
    for(let i=0; i<this.flights.length; i++){
      this.flightNameList.push(this.flights[i].flightName);
    }

    const distinct = (value, index, self) => {
      return self.indexOf(value) === index;
    }

    this.distinctFlights = this.flightNameList.filter(distinct);
  }

  seatsLayout: any = {
    totalRows: 9,
    seatsPerRow: 6,
    seatNaming: 'rowType',
    booked: [],
    checked: []
  }

  getSelected(event) {
    return true;
  }

  onChange(event: MatOptionSelectionChange) {
    this.flightName = this.distinctFlights[event.source.value];
    this.checkInService.getFlightByName(this.flightName).subscribe(data => {
      this.flightId = data;
    });
  }

  onCheck($event: MatCheckboxChange) {
    let res = $event.checked;

    if(res) {
      this.flightIdpipe = $event.source.value;

      this.checkInService.getFlightById(this.flightIdpipe).subscribe(data => {
        this.singleflight = data;
        this.resultedPassenger = this.singleflight[0].passengers;

        for(let i=0; i<this.resultedPassenger.length; i++) {
          this.seatsLayout.booked.push(this.resultedPassenger[i].seatNumber);
          if(this.resultedPassenger[i].checkIn === true) 
            this.seatsLayout.checked.push(this.resultedPassenger[i].seatNumber);
        }
          this.checkInService.flightSelected = this.resultedPassenger;
          this.ELEMENT_DATA = this.resultedPassenger;
          this.dataSource.paginator = this.paginator;
        
      });
    }

    else {
      this.flightIdpipe = null;
      this.resultedPassenger = null;
    }
    return this.singleflight;
  }

}

export interface Element {
  passengerName: string;
  ancillaryService: string;
  seatNumber: string;
}
