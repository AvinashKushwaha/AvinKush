import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CheckinComponentComponent } from './checkin-component/checkin-component.component';
import { DisplayFlightComponent } from './display-flight/display-flight.component';
import { FilterDataComponent } from './filter-data/filter-data.component';
import { CheckinSeatComponent } from './checkin-seat/checkin-seat.component';


const routes: Routes = [
    {
        path: '',
        component: CheckinComponentComponent,
        children: [
            {
                path: 'displayflight', component: DisplayFlightComponent
            },
            {
                path: 'filterdata', component: FilterDataComponent
            },
            {
                path: 'displayflight/getpassenger', component: CheckinSeatComponent
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class CheckinRoutingModule {}