import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SeatChangeComponent } from './seat-change.component';

describe('SeatChangeComponent', () => {
  let component: SeatChangeComponent;
  let fixture: ComponentFixture<SeatChangeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SeatChangeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SeatChangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
