import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InflightComponentComponent } from './inflight-component/inflight-component.component';
import { AncillaryPassengerComponent } from './ancillary-passenger/ancillary-passenger.component';
import { ServiceComponentComponent } from './service-component/service-component.component';
import { InflightRoutingModule } from './inflight-routing.module';
import { MaterialModule } from '../material/material.module';
import { FormsModule, ReactiveFormsModule } from '../../../node_modules/@angular/forms';
import { MatPaginatorModule } from '../../../node_modules/@angular/material/paginator';
import { MatSlideToggleModule } from '../../../node_modules/@angular/material/slide-toggle';
import { MatCardActions, MatCardHeader } from '../../../node_modules/@angular/material/card';
import { SharedModule } from '../shared/shared.module';
import { SeatLayoutComponent } from '../shared/seat-layout/seat-layout.component';
import { CoreModule } from '../core/core.module';
import { MatDialogModule } from '@angular/material/dialog';
import { ToastrModule } from 'ngx-toastr';



@NgModule({
  declarations: [
    InflightComponentComponent, 
    AncillaryPassengerComponent, 
    ServiceComponentComponent
  ],
  imports: [
    CommonModule,
    InflightRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    MatSlideToggleModule,
    SharedModule,
    MatPaginatorModule,
    CoreModule,
    MatDialogModule,
    ToastrModule.forRoot(),
   // MatCardActions,
   // MatCardHeader
  ],
  exports: [SeatLayoutComponent]
})
export class InflightModule { }
