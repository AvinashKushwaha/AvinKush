import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InflightComponentComponent } from './inflight-component.component';

describe('InflightComponentComponent', () => {
  let component: InflightComponentComponent;
  let fixture: ComponentFixture<InflightComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InflightComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InflightComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
