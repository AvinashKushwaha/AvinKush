import { Component, OnInit, Optional, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Passenger } from '../../shared/_models/passenger';
import { InflightRoutingModule } from '../inflight-routing.module';
import { FlightDataService } from '../../shared/flightData.service';

@Component({
  selector: 'app-service-component',
  templateUrl: './service-component.component.html',
  styleUrls: ['./service-component.component.css']
})
export class ServiceComponentComponent implements OnInit {

  local_data: any;
  passenger: Passenger;
  action: string;
  changeAncillary: false;
  changeShopping: false;
  changeSpecialMeal: false;
  ancillaryService: any[];
  shoppingItem: any[];
  resultedFlight: any;
  specialMeal: any;

  constructor(public dialogRef: MatDialogRef<ServiceComponentComponent>,
              private inflightService: FlightDataService,
              @Optional() @Inject(MAT_DIALOG_DATA) public data: Passenger) { 
                this.passenger = data;
                this.local_data = {...data};
                this.action = this.local_data.action;
              }

  ngOnInit(): void {
    this.resultedFlight = this.inflightService.getAncillaryFlight();
    this.ancillaryService = this.resultedFlight.ancillaryService;
    this.shoppingItem = this.resultedFlight.shoppingItem;
    this.specialMeal = this.resultedFlight.specialMeal;
  }

  doAction() {
    this.dialogRef.close({ data: this.passenger });
  }

  closeDialog() {
    this.dialogRef.close({ event: 'Cancel' });
  }

  editPassengerAncillary() {
    this.closeDialog();
  }

  editPassengerSpecialMeal() {
    this.closeDialog();
  }

  editPassengerShoppingItem() {
    this.closeDialog();
  }

}
