import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AncillaryPassengerComponent } from './ancillary-passenger.component';

describe('AncillaryPassengerComponent', () => {
  let component: AncillaryPassengerComponent;
  let fixture: ComponentFixture<AncillaryPassengerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AncillaryPassengerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AncillaryPassengerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
