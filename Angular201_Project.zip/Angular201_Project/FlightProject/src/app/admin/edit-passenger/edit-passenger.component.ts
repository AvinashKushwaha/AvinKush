import { Component, OnInit, Optional, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '../../../../node_modules/@angular/material/dialog';
import { Passenger } from '../../shared/_models/passenger';

@Component({
  selector: 'app-edit-passenger',
  templateUrl: './edit-passenger.component.html',
  styleUrls: ['./edit-passenger.component.css']
})
export class EditPassengerComponent implements OnInit {

  local_data: any;
  passenger: Passenger;
  action: string;

  constructor(
    public dialogRef: MatDialogRef<EditPassengerComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: Passenger
  ) { 
    console.log(data);
    this.passenger = data;
    console.log(this.passenger);
  }

  ngOnInit(): void {
  }

  doAction() {
    this.dialogRef.close({ data: this.passenger });
  }

  closeDialog() {
    this.dialogRef.close({ event: 'Cancel' });
  }

}
