import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FilterPassengerComponent } from './filter-passenger.component';

describe('FilterPassengerComponent', () => {
  let component: FilterPassengerComponent;
  let fixture: ComponentFixture<FilterPassengerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FilterPassengerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterPassengerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
