import { Component, OnInit } from '@angular/core';
import { SidenavService } from '../../shared/services/sidenav.service';
import { onMainContentChange } from '../../shared/animation/animation';

@Component({
  selector: 'app-admin-component',
  templateUrl: './admin-component.component.html',
  styleUrls: ['./admin-component.component.css'],
  animations: [ onMainContentChange ]
})

export class AdminComponentComponent implements OnInit {
  public onSideNavChange: boolean;

  constructor(private _sidenavService: SidenavService) {
    this._sidenavService.sideNavState$.subscribe(res => {
      console.log(res)
      this.onSideNavChange = res;
    })
   }

  ngOnInit(): void {
  }

}
