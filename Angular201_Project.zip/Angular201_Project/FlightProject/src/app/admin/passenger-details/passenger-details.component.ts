import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validator, FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { MatOptionSelectionChange } from '@angular/material/core';
import { FlightDataService } from '../../shared/flightData.service';
import { MatCheckboxChange } from '../../../../node_modules/@angular/material/checkbox';
import { AddPassengerComponent } from '../add-passenger/add-passenger.component';
import { Passenger } from '../../shared/_models/passenger';
import { EditPassengerComponent } from '../edit-passenger/edit-passenger.component';
import { MatPaginator } from '../../../../node_modules/@angular/material/paginator';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-passenger-details',
  templateUrl: './passenger-details.component.html',
  styleUrls: ['./passenger-details.component.css']
})
export class PassengerDetailsComponent implements OnInit {

  @ViewChild(MatPaginator, { static: true}) paginator: MatPaginator;

  DetailsForm: FormGroup;
  name = 'Angular 5';
  displayedColumns = ['customerName', 'AncillaryServices', 'seatNumber'];
  displayedColumns2 = ['customerName', 'passport', 'address', 'edit'];
  ELEMENT_DATA: Element[] = [];
  dataSource: any;

  constructor(private formBuilder: FormBuilder,
              private adminService: FlightDataService,
              private dialog: MatDialog,
              private toasterService: ToastrService
              ) { }

  flightResponse: any[] = [];
  search: string;
  sortResult: any[] = [];
  searchText: string;
  data: any;
  passengers: any;
  flights: any;
  passengerDetails: any[] = [];
  flightName: any;
  myflight: any;
  flightNameList: any = [];
  distinctFlights: any = [];
  singleflight: any;
  flightIdpipe: any;
  resultedPassenger: any = [];
  dialogData: any;
  selectedSeatChange: any;
  result: any;
  passenger: Passenger;
  dialogRef2: any;

  ngOnInit(): void {
    this.DetailsForm = this.formBuilder.group({
      passengerName: ['', Validators.required]
    });

    this.adminService.getflights().subscribe(data => {
      this.flights = data;
      console.log(this.flights);
      this.getUniqueFlight();
    })
  }

  get f() { return this.DetailsForm.controls; }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  getUniqueFlight() {
    for (let i=0; i<this.flights.length; i++) {
      this.flightNameList.push(this.flights[i].flightName);
    }
    const distinct = (value, index, self) => {
      return self.indexOf(value) === index;
    }
    this.distinctFlights = this.flightNameList.filter(distinct);
    console.log(this.distinctFlights);
  }

  onChange(event: MatOptionSelectionChange) {
    console.log(event.source.value);
    this.flightName = this.distinctFlights[event.source.value];
    console.log(this.flightName);
    this.adminService.getFlightByName(this.flightName).subscribe(data => {
      this.myflight = data;
    });
  }

  onCheck($event: MatCheckboxChange){
    let res = $event.checked;
    console.log($event.source.value)
    if(res) {
      this.flightIdpipe = $event.source.value;
      //this.flightIdpipe = "8E-1011";
      console.log(this.flightIdpipe)
      this.adminService.getFlightById(this.flightIdpipe).subscribe(data => {
        this.singleflight = data;
        console.log(this.singleflight)
        this.resultedPassenger = this.singleflight[0].passengers;
        this.ELEMENT_DATA = this.resultedPassenger;
        this.dataSource = new MatTableDataSource<Element>(this.ELEMENT_DATA);
        this.dataSource.paginator = this.paginator;
      });
    }
    return this.resultedPassenger;
  }

  addNew() {
    const dialogRef = this.dialog.open(AddPassengerComponent, {
      data: { passenger: Passenger }
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result === 1) {
        console.log("Added!!");
      }
    });
  }

  openDialogEdit(action: string, obj: any) {
    this.dialogData = obj;
    this.dialogRef2 = this.dialog.open(EditPassengerComponent, {
      maxWidth: "50%",
      data: this.dialogData
    });

    this.dialogRef2.afterClosed().subscribe(dialogResult => {
      this.result = dialogResult;
      for (let i=0; i<this.resultedPassenger.length; i++) {
        if (this.resultedPassenger[i].customerName === this.dialogData.customerName && this.resultedPassenger[i].seatNumber === this.dialogData.seatNumber){
          this.resultedPassenger[i].customerName === this.dialogData.customerName;
          this.resultedPassenger[i].passport = this.dialogData.passport;
          this.resultedPassenger[i].address = this.dialogData.address;
        }
      }

      this.singleflight.passengers = this.resultedPassenger;
      this.adminService.updatePassenger(this.singleflight[0].id, this.singleflight[0]).subscribe(data => {
        this.toasterService.success('Update Passenger Successfully');
      },
      error => {
        this.toasterService.warning('Error in updating details');
      }
      )
    });
  }

}

export interface Element {
  passengerName: string;
  ancillaryService: string;
  seatNumber: string;
}
