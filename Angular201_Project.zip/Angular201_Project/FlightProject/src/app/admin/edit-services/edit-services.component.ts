import { Component, OnInit, Inject, Optional } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '../../../../node_modules/@angular/material/dialog';
import { AncillaryPassengerComponent } from 'src/app/inflight/ancillary-passenger/ancillary-passenger.component';

@Component({
  selector: 'app-edit-services',
  templateUrl: './edit-services.component.html',
  styleUrls: ['./edit-services.component.css']
})
export class EditServicesComponent implements OnInit {

  ancillary: Ancillary;

  constructor(public dialogRef: MatDialogRef<EditServicesComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any) { 
      console.log(data);
      this.ancillary = data;
      console.log(this.ancillary);
    }

    doAction() {
      this.dialogRef.close({ data: this.ancillary });
    }

    closeDialog() {
      this.dialogRef.close({ event: 'Cancel' });
    }

  ngOnInit(): void {
  }

}

export class Ancillary {

}
