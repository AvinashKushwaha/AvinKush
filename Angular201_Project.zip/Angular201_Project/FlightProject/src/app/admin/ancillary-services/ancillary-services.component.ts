import { Component, OnInit, ViewChild } from '@angular/core';
import { FlightDataService } from '../../shared/flightData.service';
import { MatOptionSelectionChange } from '../../../../node_modules/@angular/material/core';
import { MatCheckboxChange } from '../../../../node_modules/@angular/material/checkbox';
import { MatTableDataSource } from '../../../../node_modules/@angular/material/table';
import { MatDialog } from '../../../../node_modules/@angular/material/dialog';
import { EditServicesComponent } from '../edit-services/edit-services.component';
import { MatPaginator } from '../../../../node_modules/@angular/material/paginator';

@Component({
  selector: 'app-ancillary-services',
  templateUrl: './ancillary-services.component.html',
  styleUrls: ['./ancillary-services.component.css']
})

export class AncillaryServicesComponent implements OnInit {

  @ViewChild(MatPaginator, { static: true}) 
  paginator: MatPaginator;

  constructor( private adminService: FlightDataService,
               private dialog: MatDialog) { }
           
  myFlight: any;
  flightNameList: any = [];
  distinctFlights: any = [];
  flightName: any;
  someValue: any;
  plane: any = [];
  singleflight: any = [];
  flightIdpipe: any;
  resultedFlight: any;
  changeAncillary: false;
  changeShopping: false;
  changeSpecialMeal: false;
  dialogData: any;
  displayedColumns = ['AncillaryServices', 'editServices'];
  ELEMENT_DATA: Element[] = [];
  dataSource: any;
  openService = false;            

  ngOnInit(): void {

    this.adminService.getflights().subscribe(data => {
      this.myFlight = data;
      console.log(this.myFlight);

      this.getUniqueFlight();
    });
  }

  getUniqueFlight() {
    for (let i=0; i<this.myFlight.length; i++) {
      this.flightNameList.push(this.myFlight[i].flightName);
    }
    const distinct = (value, index, self) => {
      return self.indexOf(value) === index;
    }
    this.distinctFlights = this.flightNameList.filter(distinct);
  }

  onChange(event: MatOptionSelectionChange) {
    this.flightName = this.distinctFlights[event.source.value];
    this.adminService.getFlightByName(this.flightName).subscribe(data => {
      this.plane = data;
    });
  }

  onCheck($event: any) {
    let res = $event.checked;
    if(res)  {
      this.flightIdpipe = $event.source.value;
      this.adminService.getFlightById(this.flightIdpipe).subscribe(data => {
        this.singleflight = data;
        this.resultedFlight = this.singleflight[0];
        this.ELEMENT_DATA = this.resultedFlight.AncillaryServices;
        this.dataSource = new MatTableDataSource<Element>(this.ELEMENT_DATA);
        this.dataSource.paginator = this.paginator;
        this.openService = true;
      });
    }
  }

  addAncillary() {
    this.resultedFlight.ancillaryServices = this.resultedFlight.ancillaryServices.split(',');
    this.adminService.updateAncillary(this.resultedFlight.id, this.resultedFlight).subscribe(data => {
      console.log("Update Ancillary Service Successful")
    });

    this.changeAncillary = false;
  }

  addSpecialMeal() {
    console.log(this.resultedFlight);
    this.resultedFlight.specialMeal = this.resultedFlight.specialMeal.split(',');
    this.adminService.updateSpecialMeal(this.resultedFlight.id, this.resultedFlight).subscribe(data => {
      console.log("Special Meal updated Successfully")
    });
    this.changeSpecialMeal = false;
  }

  addShoppingItem() {
    this.resultedFlight.shoppingItem = this.resultedFlight.shoppingItem.split(',');
    this.adminService.updateShoppingItem(this.resultedFlight.id, this.resultedFlight).subscribe(data => {
      console.log("Shopping Items updated Successfully")
    });
    this.changeShopping = false;
  }

}
