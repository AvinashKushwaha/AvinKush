export const environment = {
  apiUrl: 'http://localhost:4200',
  production: true
};
